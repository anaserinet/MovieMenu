#ifndef PELICULA_HPP
#define PELICULA_HPP
#include <iostream>
#include <string>
#include <list>
class VideoPelicula : public Video 
{
  private:
    std::string nombreSerie;
    std:: string nombreEpisodio;
    int numeroEpisodio;
    std::string temporada;
}
  public:
    VideoSerie(int numID_vid = 0, std::string nombre_vid = "", float duracionMin_vid = 0, std::string genero_vid = "", float promedio_vid = 0, std::string nombreSerie = "", int numeroEpisodio = 0, std::string temporada = "");
    void mostrarInformacion(float promedio, float ultima_calificacion);

void setDatos(std:string nomEp, std::string nomSerie);




#endif 