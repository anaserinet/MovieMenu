#include "pelicula.hpp"

//Constructor 
VideoPelicula::VideoPelicula(int numID_vid, std::string nombre_vid, float duracionMin_vid, std::string genero_vid, float promedio_vid, std::string nombreSerie, int numeroEpisodio, std::string temporada);